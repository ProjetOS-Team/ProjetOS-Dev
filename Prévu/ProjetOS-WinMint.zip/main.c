#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdbool.h>
#include <stdio.h>

#define TASKBAR_HEIGHT 50
#define WINDOW_MIN_WIDTH 640
#define WINDOW_MIN_HEIGHT 360

typedef struct {
    SDL_Rect rect;
    bool visible;
    bool minimized;
    const char* title;
} WindowSim;

void drawText(SDL_Renderer* renderer, TTF_Font* font, const char* text, int x, int y, SDL_Color color) {
    SDL_Surface* surface = TTF_RenderUTF8_Blended(font, text, color);
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_Rect destRect = {x, y, surface->w, surface->h};
    SDL_RenderCopy(renderer, texture, NULL, &destRect);
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}

void afficherNotification(SDL_Renderer* renderer, TTF_Font* font, const char* message, int width) {
    SDL_Color notifColor = {255, 255, 255};
    SDL_Surface* surface = TTF_RenderUTF8_Blended(font, message, notifColor);
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);

    SDL_Rect notifRect = {20, 20, surface->w + 20, surface->h + 20};
    SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
    SDL_RenderFillRect(renderer, &notifRect);

    SDL_Rect textRect = {notifRect.x + 10, notifRect.y + 10, surface->w, surface->h};
    SDL_RenderCopy(renderer, texture, NULL, &textRect);
    SDL_RenderPresent(renderer);

    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
    SDL_Delay(3000);
}

void drawWindowHeader(SDL_Renderer* renderer, SDL_Rect* rect, const char* title, TTF_Font* font) {
    SDL_Rect header = {rect->x, rect->y, rect->w, 30};
    SDL_SetRenderDrawColor(renderer, 45, 45, 55, 255);
    SDL_RenderFillRect(renderer, &header);
    drawText(renderer, font, title, rect->x + 10, rect->y + 5, (SDL_Color){255, 255, 255});

    // Close Button
    SDL_Rect closeBtn = {rect->x + rect->w - 30, rect->y, 30, 30};
    SDL_SetRenderDrawColor(renderer, 200, 50, 50, 255);
    SDL_RenderFillRect(renderer, &closeBtn);
    drawText(renderer, font, "X", closeBtn.x + 10, closeBtn.y + 5, (SDL_Color){255, 255, 255});
}

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();

    SDL_Window* window = SDL_CreateWindow("ProjetOS WinMint", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                          960, 540, SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    TTF_Font* font = TTF_OpenFont("Sansation-Regular.ttf", 20);
    if (!font) {
        printf("Erreur de police : %s\n", TTF_GetError());
        return 1;
    }

    // Boot screen stylisé
    SDL_SetRenderDrawColor(renderer, 10, 10, 15, 255);
    SDL_RenderClear(renderer);
    drawText(renderer, font, "Démmarage de ProjetOS WinMint", 360, 250, (SDL_Color){180, 180, 255});
    SDL_Rect loading = {430, 290, 100, 10};
    for (int i = 0; i <= 100; i += 5) {
        SDL_SetRenderDrawColor(renderer, 40, 40, 40, 255);
        SDL_RenderFillRect(renderer, &loading);
        SDL_SetRenderDrawColor(renderer, 120, 200, 255, 255);
        SDL_Rect progress = {loading.x, loading.y, i, loading.h};
        SDL_RenderFillRect(renderer, &progress);
        SDL_RenderPresent(renderer);
        SDL_Delay(100);
    }

    bool running = true;
    SDL_Event event;
    bool menuOpen = false;
    bool showSettings = false;
    bool showTerminal = false;

    WindowSim settingsWin = {{200, 100, 400, 300}, true, false, "Paramètres"};
    WindowSim terminalWin = {{250, 150, 450, 300}, true, false, "Terminal"};

    afficherNotification(renderer, font, "Exemple de notification", 960);

    while (running) {
        int winW, winH;
        SDL_GetWindowSize(window, &winW, &winH);

        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) running = false;
            else if (event.type == SDL_MOUSEBUTTONDOWN) {
                int mx = event.button.x;
                int my = event.button.y;

                if (mx >= 10 && mx <= 100 && my >= winH - TASKBAR_HEIGHT + 10 && my <= winH - 10)
                    menuOpen = !menuOpen;

                if (menuOpen) {
                    if (my >= winH - TASKBAR_HEIGHT - 95 && my <= winH - TASKBAR_HEIGHT - 75)
                        showSettings = true;
                    else if (my >= winH - TASKBAR_HEIGHT - 65 && my <= winH - TASKBAR_HEIGHT - 45)
                        showTerminal = true;
                    else if (my >= winH - TASKBAR_HEIGHT - 35 && my <= winH - TASKBAR_HEIGHT - 15)
                        running = false;
                }
            }
        }

        // Bureau
        SDL_SetRenderDrawColor(renderer, 25, 25, 35, 255);
        SDL_RenderClear(renderer);

        // Barre des tâches
        SDL_Rect taskbar = {0, winH - TASKBAR_HEIGHT, winW, TASKBAR_HEIGHT};
        SDL_SetRenderDrawColor(renderer, 20, 20, 25, 255);
        SDL_RenderFillRect(renderer, &taskbar);

        SDL_Rect menuBtn = {10, winH - TASKBAR_HEIGHT + 10, 90, 30};
        SDL_SetRenderDrawColor(renderer, 90, 90, 120, 255);
        SDL_RenderFillRect(renderer, &menuBtn);
        drawText(renderer, font, "Menu", 25, winH - TASKBAR_HEIGHT + 15, (SDL_Color){255, 255, 255});

        if (menuOpen) {
            SDL_Rect menu = {10, winH - TASKBAR_HEIGHT - 110, 300, 100};
            SDL_SetRenderDrawColor(renderer, 40, 40, 60, 255);
            SDL_RenderFillRect(renderer, &menu);
            drawText(renderer, font, "- Paramètres", 20, winH - TASKBAR_HEIGHT - 95, (SDL_Color){255, 255, 255});
            drawText(renderer, font, "- Terminal", 20, winH - TASKBAR_HEIGHT - 65, (SDL_Color){255, 255, 255});
            drawText(renderer, font, "- Arreter", 20, winH - TASKBAR_HEIGHT - 35, (SDL_Color){255, 100, 100});
        }

        // Fenêtre paramètres
        if (showSettings && settingsWin.visible && !settingsWin.minimized) {
            SDL_SetRenderDrawColor(renderer, 60, 60, 80, 255);
            SDL_RenderFillRect(renderer, &settingsWin.rect);
            drawWindowHeader(renderer, &settingsWin.rect, settingsWin.title, font);
            drawText(renderer, font, "Réglages système", settingsWin.rect.x + 10, settingsWin.rect.y + 40, (SDL_Color){255, 255, 255});
        }

        // Fenêtre terminal
        if (showTerminal && terminalWin.visible && !terminalWin.minimized) {
            SDL_SetRenderDrawColor(renderer, 15, 15, 20, 255);
            SDL_RenderFillRect(renderer, &terminalWin.rect);
            drawWindowHeader(renderer, &terminalWin.rect, terminalWin.title, font);
            drawText(renderer, font, "ProjetOS WinMint Indique: Terminal en travaille", terminalWin.rect.x + 10, terminalWin.rect.y + 40, (SDL_Color){0, 255, 0});
        }

        SDL_RenderPresent(renderer);
        SDL_Delay(16);
    }

    TTF_CloseFont(font);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    TTF_Quit();
    SDL_Quit();
    return 0;
}
